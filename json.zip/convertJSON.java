import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;


public class convertJSON {

	
	private static final String ROOT = "root";
	private static final String SUBROOT = "subRoot";
	private static final String ITEM = "item";

	private static final String TITLE = "title";
	private static final String DESCRIPTION = "description";
	private static final String LINK = "link";
	private static final String PUBDATE = "pubDate";
	private static final String ENCLOUSURE = "enclosure";
	private static final String URL = "url";
	
	private static final String ORIGEN = "origen";
	
	private static final String TABLE = "table";
	private static final String SCHEDULE = "schedule";
	private static final String FEEDPARAMS = "feedParams";
	private static final String FEEDS = "feeds";
	
	
	
	public static void main(String[] args) {
		
		
		String file = "C:/Users/ablamon/Downloads/leganes/feeds.json";
		
		try {
			String jsonString = readJSON(file);
			System.out.println(jsonString);
			
			JSONObject obj = new JSONObject(jsonString);
			
			String scheduleUrl = obj.getString(TABLE);
			String tableUrl = obj.getString(SCHEDULE);
			ArrayList<XMLParser> listParser = getListParser(obj);
			

			System.out.println(scheduleUrl + tableUrl);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public static String readJSON(String file) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(file));
		try {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();
	
		    while (line != null) {
		        sb.append(line);
		        line = br.readLine();
		    }
		    return sb.toString();
		} finally {
		    br.close();
		}
	}
	
	public static ArrayList<XMLParser> getListParser(JSONObject obj) {
		
		JSONObject feedParamsParent = obj.getJSONObject(FEEDPARAMS);
		
		JSONArray feeds = obj.getJSONArray(FEEDS);
		ArrayList<XMLParser> listParser = new ArrayList<XMLParser>();
		
		for (int i = 0, size = feeds.length(); i < size; i++) {
			
	      JSONObject feed = feeds.getJSONObject(i);
	      
	      String url    = feed.has(URL)    ? feed.getString(URL)    : "";
	      String origen = feed.has(ORIGEN) ? feed.getString(ORIGEN) : "";
	      
	      XMLParser xmlParser;
	      
	      if(feed.has(FEEDPARAMS)){
	      
	    	  JSONObject feedParams = feed.getJSONObject(FEEDPARAMS);
	    	  xmlParser = createXMLParser(feedParams, url, origen);
			
	      } else {
	    	  
	    	  xmlParser = createXMLParser(feedParamsParent, url, origen);
	    	  
	      }
	      
	      listParser.add(xmlParser);
	      
	    }
		
		return listParser;
		
	}
	
	public static XMLParser createXMLParser(JSONObject feedParams, String url, String origen) {
		
		String root        = feedParams.has(ROOT)        ? feedParams.getString(ROOT)        : "";
      	String subRoot     = feedParams.has(SUBROOT)     ? feedParams.getString(SUBROOT)     : "";
		String item        = feedParams.has(ITEM)        ? feedParams.getString(ITEM)        : "";

		String title       = feedParams.has(TITLE)       ? feedParams.getString(TITLE)       : "";
		String description = feedParams.has(DESCRIPTION) ? feedParams.getString(DESCRIPTION) : "";
		String link        = feedParams.has(LINK)        ? feedParams.getString(LINK)        : "";
		String pubDate     = feedParams.has(PUBDATE)     ? feedParams.getString(PUBDATE)     : "";
		String enclousure  = feedParams.has(ENCLOUSURE)  ? feedParams.getString(ENCLOUSURE)  : "";
		String urlParser   = feedParams.has(URL)         ? feedParams.getString(URL)         : "";
		
		return new XMLParser(root, subRoot, item, title, description, link, pubDate, enclousure, urlParser, url, origen);
		
	}

}
