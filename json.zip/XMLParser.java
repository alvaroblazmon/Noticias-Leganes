import org.json.JSONObject;


public class XMLParser {
	
	
	private String root = "rss";
	private String subRoot = "channel";
	private String item = "item";

	private String title = "title";
	private String description = "description";
	private String link = "link";
	private String pubDate = "pubDate";
	private String enclosure = "enclosure";
	private String urlParser = "url";
    
	private String url = "";
	private String origen = "";
	
	public XMLParser(String root, String subRoot,
			String item, String title,
			String description, String link,
			String pubDate, String enclosure,
			String urlParser, String url,
			String origen) {
		
		super();
		this.root = root;
		this.subRoot = subRoot;
		this.item = item;
		this.title = title;
		this.description = description;
		this.link = link;
		this.pubDate = pubDate;
		this.enclosure = enclosure;
		this.urlParser = urlParser;
		this.url = url;
		this.origen = origen;
		
	}

}
